function [histF w]=fuzzyhist(image,mask,k)

    %This function will calculate the fuzzy histogram of the image which has
    %been segmented into 'k' segments and whose mask is provided in the
    %varaible 'mask'.

    %The inputs to this code:
    % 1)image: It is assumed to be a RGB image.
    % 2)mask: This 2-d array which of the same size as that of the image tells
    %          which pixel in the image belonhgs to which cluster.
    % 3)k: The number of cluster into which the image has been clustered.

    %The output is k x 96 array whose ith row is the fuzzy histogram of ith
    %cluster

    %The following things happen in this code:
    % 1)The RGB image is converted to Lab space.
    % 2)The image is uniformaly quantized into 96 bins. 6 for 'L', 4 each for
    %   'a' and 'b' components.
    % 3)The distance matrix is computed which is 96x96 and stores the distance
    %   between each colour bin.
    % 4)For each cluster, find the normal histogram. (This histogram is of length 96)
    % 5)Using the normal histgram and the distance matrix we can calculate the
    %   fuzzy histogram of the cluster.

%     image=RGB2Lab(image);
    histF=zeros(k,96);

    %%%%%%%%%%%%%%%%%%%%%%%%%%% Image Quantization %%%%%%%%%%%%%%%%%%%%%%%%
    copy=double(image);             %To avoid the rounding of error due to dividing by 'quant'
    
    
    copy(:,:,1)=image(:,:,1)-min(min(image(:,:,1)))+1;   
    quant=ceil(max(max(copy(:,:,1)))/6);
    copy(:,:,1)=ceil(copy(:,:,1)/quant);
       
    copy(:,:,2)=image(:,:,2)+1-min(min(image(:,:,2)));
    quant=ceil(max(max(copy(:,:,2)))/4);
    copy(:,:,2)=ceil(copy(:,:,2)/quant);
    
    copy(:,:,3)=image(:,:,3)-min(min(image(:,:,3)))+1;
    quant=ceil(max(max(copy(:,:,3)))/4);
    copy(:,:,3)=ceil(copy(:,:,3)/quant);
    
%     min(min(copy(:,:,1)))
%     min(min(copy(:,:,2)))
%     min(min(copy(:,:,3)))
%     
%     max(max(copy(:,:,1)))
%     max(max(copy(:,:,2)))
%     max(max(copy(:,:,3)))
    
    copy=uint8(copy);         %This is the new quantized image.
%     figure;
%     imshow(40*copy);
%     title('FuzzyHIst, quant image')
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    
    %%%%%%%%%%%%%%%% Calculating the average distance, sig %%%%%%%%%%%%%%%%
    total=0;
    for i=1:95
        for j=i+1:96
            [x1 y1 z1]=ind2sub([6 4 4],i);
            [x2 y2 z2]=ind2sub([6 4 4],j);
            space=[x1 y1 z1]-[x2 y2 z2];
            total=total+sqrt(sum(space.*space));
        end
    end
    sig=sqrt(total*2/(96*95));
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    
    %%%%%%%%%%%%%%%%%%%%% Computing the distance matrix %%%%%%%%%%%%%%%%%%%
    dist=ones(96,96);  %The i,j entry of this matric is the colour distance between the ith and jth bin
    for i=1:96
        for j=i:96
            [x1 y1 z1]=ind2sub([6 4 4],i);
            [x2 y2 z2]=ind2sub([6 4 4],j);
            space=[x1 y1 z1]-[x2 y2 z2];
            d=(sum(space.*space));
            dist(i,j)=1/(1+d/sig);
            dist(j,i)=dist(i,j);
        end
    end
%     disp('The max value in the dist matrix');
%     max(max(dist))
%     disp('the min value in the dist matrix');
%     min(min(dist))
%     figure;
%     imshow(uint8(255*(dist)));
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    
    %%%%%%%%%%%% Computing the normal histogram for each cluster %%%%%%%%%%    
    histN=zeros(k,96);
%     pixelcount=0;
    w=zeros(1,k);
    for i=1:k
        [x y]=ind2sub(size(mask),find(mask==i));
        %x and y arrays contain the indices in the image which will belong
        %to the ith cluster.
        w(i)=length(x);
        if (~isempty(x))
            for point=1:length(x)
%                 pixelcount=pixelcount+1;
                L=copy(x(point),y(point),1);
                a=copy(x(point),y(point),2);
                b=copy(x(point),y(point),3);
                binindex=sub2ind([6 4 4],L,a,b);
                histN(i,binindex)=histN(i,binindex)+1;
            end
        end
%         disp('the number of pixels are:');
%         pixelcount
%         figure;
%         plot(histN(i,:))
    end
    for i=1:k
        histN(i,:)=histN(i,:)/max(histN(i,:));
    end
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    
    %%%%%%%%%%%%%%%%%%%%%% Computing the fuzzy histogram %%%%%%%%%%%%%%%%%%
    
    for i=1:k
        for col=1:96
            histF(i,col)=sum(histN(i,:).*dist(col,:));
        end
        histF(i,:)=histF(i,:)/max(histF(i,:));
        
%         figure;
%         title(i);
%         subplot(2,1,1);
%         bar(histN(i,:));
%         subplot(2,1,2);
%         bar(histF(i,:));
        
    end
%     figure;
%     plot(dist(50,:));
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%   
end





