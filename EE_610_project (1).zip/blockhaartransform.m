function A=blockhaartransform(L)

% This function calculates the haar transform of the image in the following
% steps:
% 1) The image is split into 4x4 pixel blocks.
% 2) For each of these blocks Haar transform is calculated which gives 4 blocks 
%    of size 2x2. These four blocks correspond to LL HL LH ans HH freq components
%    of the 4x4 image block.
% 3) The HL LH and HH components are used to calculate the texture of the block. 
%    The average value of these components are the 3 texture features assigned to 4x4
%    block
   
   
    
    [dx,dy] = size(L);      % L = The L values matrix of the initial Image in LAB space. 
    SCH = zeros(4*floor(dx/4),4*floor(dy/4));
    DCH = zeros(4*floor(dx/4),4*floor(dy/4));
    SRH = zeros(4*floor(dx/4),4*floor(dy/4));
    DRH = zeros(4*floor(dx/4),4*floor(dy/4));


    for i = 1:4:4*floor(dx/4)
        for j = 1:4:4*floor(dy/4)

            for x = i: i+3
                for y = j: j+3
                    if ( y ~= j)
                        SCH(x,y) = L(x,y) + L(x,y-1);
                    else
                        SCH(x,y) = L(x,y);
                    end
                end
            end


            for r = i: i+3
                for t = j: j+3
                    if ( t ~= j)
                        DCH(r,t) = L(r,t-1) - L(r,t);
                    else
                        DCH(r,t) = -L(r,t);
                    end
                end
            end   
            a = i;
            l = j; 
            for k = a:a+3
                CH(k,l)   = SCH(k,l+1);
                CH(k,l+1) = SCH(k,l+3);
                CH(k,l+2) = DCH(k,l+1);
                CH(k,l+3) = DCH(k,l+3);
            end


             for y= j: j+3
                for x = i: i+3
                    if ( x ~= i)
                        SRH(x,y) = CH(x,y) + CH(x-1,y);
                    else
                        SRH(x,y) = CH(x,y);
                    end
                end
             end


            for y= j: j+3
                for x = i: i+3
                    if ( x ~= i)
                        DRH(x,y) = CH(x-1,y) - CH(x,y);
                    else
                        DRH(x,y) = -CH(x,y);
                    end
                end
            end

            r1 = i; 
            b = j; 
            for t1 =b:b+3
            H(r1,t1) = SRH(r1+1,t1);
            H(r1+1,t1) = SRH(r1+3,t1);
            H(r1+2,t1) = DRH(r1+1,t1);
            H(r1+3,t1) = DRH(r1+3,t1); 
            end 
        end
    end 
    % H is the 4*4 block haar transform of the initial image. 
    %[dx,dy] = size(H); 

    T1 = zeros(floor(dx/4),floor(dy/4));
    T2 = zeros(floor(dx/4),floor(dy/4));
    T3 = zeros(floor(dx/4),floor(dy/4));

    for i = 1:4:4*floor(dx/4)
        for j = 1:4:4*floor(dy/4)
            T1((i+3)/4,(j+3)/4) = (H(i,j+2))/4 + (H(i,j+3))/4 + (H(i+1,j+2))/4 + (H(i+1,j+3))/4; 
            T2((i+3)/4,(j+3)/4) = (H(i+2,j))/4 + (H(i+2,j+1))/4 + (H(i+3,j))/4 + (H(i+3,j+1))/4;
            T3((i+3)/4,(j+3)/4) = (H(i+2,j+2))/4 + (H(i+2,j+3))/4 + (H(i+3,j+2))/4 + (H(i+3,j+3))/4; 
        end 
    end 
    A=zeros(floor(dx/4),floor(dy/4),3);

    A(:,:,1)=T1;
    A(:,:,2)=T2;
    A(:,:,3)=T3;

    

end