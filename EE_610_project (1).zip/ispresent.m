function out=ispresent(tex_space,value)

    
    % tex_space = m x 3 vector
    % value = a 1 x 3 vector 
    % To check if value is present in tex_space or not

    out=0;

    if(isempty(tex_space))
        return;
    end
    x=find(tex_space(:,1)==value(1));
    %x contains the indices of tex_space vectors whose first index matches that
    %of value.

    if (isempty(x))
        return;
    end

    tex_space=tex_space(x,:);
    y=find(tex_space(:,2)==value(2));

    if(isempty(y))
        return
    end

    tex_space=tex_space(y,:);
    z=find(tex_space(:,3)==value(3));

    if(isempty(z))
        return;
    end

    out=1;
    return
end

