function output=offline 

    %This function runs on a directory of images whose features have to be
    %extracted and strored for indexing for implementation of the Retrieval
    %of images.
    %The data for each image is stored in a struct which contains the image
    %itself, its segmented image, the fuzzy histogram for each image, the
    %fuzzy texture of each block and few other details needed to calculate the
    %distance between two images.
    
    
    list=dir;

    output=struct('image',{},'outimage',{},'mask',{},'K',{},'histC',{},'W',{},'tex',{},'imname',{});
    avght=0;
    avgwd=0;

    for i =3:length(list)
        imname = list(i).name
        image=imread(imname);
        [outimage mask K histC W]=segment(image);
        tex=fuzzyTex(image,mask,K);
        [x y ]=size(image);
        avght=avght+x;
        avgwd=avgwd+y;

        output(i).image=image;
        output(i).outimage=outimage;
        output(i).mask=mask;
        output(i).K=K;
        output(i).histC=histC;
        output(i).W=W;
        output(i).tex=tex;
        output(i).imname = imname;
    end
    avgwd=avgwd/10
    avght=avght/10
    
    save('data.mat','output');
end