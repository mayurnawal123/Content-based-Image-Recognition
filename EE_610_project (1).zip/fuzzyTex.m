function fuzzyT=fuzzyTex(image,mask,K)

%This function calculates the fuzzy texture of each of the cluster, It does
%so in the following manner.

% 1) The image is first subjected to Haar transform using the function 
% haarblock trasnform. This function first changes the image into blocks of 4x4
% and then finds the haar transform of each of those blocks individually.
% 
% 2) The output of the above function are three (small) images which together 
% make the texture feature.
% 
% 3) The small images of the above function are then converted to full size images 
% and the the mask is applied to find the averege texture of each region.
% 
% 4) An array of all the present features is constructed.
% 
% 5) The distance of all the present texture features is calculated from each of the 
% average texture features of the region.
% 
% 6) Then the fuzzy texture of each region is calculated.

image_l=RGB2Lab(image);
L=image_l(:,:,1);


%% Finding the haar transform and then converting it to the whole image %%
HaarT=blockhaartransform(L);

[x y z]=size(image);
a=floor(x/4);
b=floor(y/4);
WholeHaar=zeros(4*a,4*b,3);
for i=1:a
    for j=1:b
        for p=4*i-3:4*i
            for q=4*j-3:4*j
                 WholeHaar(p,q,1)=HaarT(i,j,1);
                 WholeHaar(p,q,2)=HaarT(i,j,2);
                 WholeHaar(p,q,3)=HaarT(i,j,3);
            end
        end
    end
end
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


%%%%%%%%%%%%%%% Finding the texture feature space in HaarT %%%%%%%%%%%%%%%%

tex_space=[];

for i=1:a
    for j=1:b
        if( ~ispresent(tex_space,HaarT(i,j,1:3)) )
            tex_space=[tex_space;HaarT(i,j,1:3)];    
        end
    end
end

[num_tex ~]=size(tex_space);

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%%%%%%%%%%% Finding the average texture feature of each cluster %%%%%%%%%%%

avg_tex=zeros(K,3);
mask=mask(1:4*a,1:4*b);
count=zeros(1,K);
for i=1:K
        [x y]=ind2sub(size(mask),find(mask==i));
        %x and y arrays contain the indices in the image which will belong
        %to the ith cluster.
        if (~isempty(x))
            for point=1:length(x)
                count(i)=count(i)+1;
                avg_tex(i,1)=avg_tex(i,1)+WholeHaar(x(point),y(point),1);
                avg_tex(i,1)=avg_tex(i,2)+WholeHaar(x(point),y(point),2);
                avg_tex(i,1)=avg_tex(i,3)+WholeHaar(x(point),y(point),3);                
            end
            avg_tex(i,1:3)=avg_tex(i,1:3)/count(i);
        end    
end
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


sig=0;
for i=1:K-1
    for j=i+1:K
        dist=avg_tex(i,:)-avg_tex(j,:);
        dist=dist.*dist;
        dist=sqrt(sum(dist));
        sig=sig+dist;
    end
end
sig=2*sig/(K*(K-1));

%%%%% Finding the distance of each tex feauture from all the averages %%%%%

dist_frm_avg=zeros(K,num_tex);

for i=1:K
    for j=1:num_tex
        dist=avg_tex(i,:)-tex_space(j,:);
        dist=dist.*dist;
        dist=sqrt(sum(dist));
        dist_frm_avg(i,j)=1/(1+dist/sig);
    end
end
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

fuzzyT=zeros(K,3);

for i=1:K
    fuzzyT(i,1)=sum(dist_frm_avg(i,:).*tex_space(:,1)');
    fuzzyT(i,2)=sum(dist_frm_avg(i,:).*tex_space(:,2)');
    fuzzyT(i,3)=sum(dist_frm_avg(i,:).*tex_space(:,3)');
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% testavgf=zeros(1,K);
% for i=1:K
%     testavgf(i)=fuzzyT(i,1)^2+fuzzyT(i,2)^2+fuzzyT(i,3)^2;
% end
% figure;
% plot(testavgf)
% title('before equalisation (fuzzy)');


% testavg=zeros(1,K);
% for i=1:K
%     testavg(i)=avg_tex(i,1)^2+avg_tex(i,2)^2+avg_tex(i,3)^2;
% end
% figure;
% plot(testavg);
% title('not fuzzy., no nomalisation');

testavgf=zeros(1,K);
for i=1:K
    testavgf(i)=fuzzyT(i,1)^2+fuzzyT(i,2)^2+fuzzyT(i,3)^2;
end
fuzzyT=fuzzyT/sqrt(max(testavgf(i)));

% testavgf=zeros(1,K);
% for i=1:K
%     testavgf(i)=fuzzyT(i,1)^2+fuzzyT(i,2)^2+fuzzyT(i,3)^2;
% end
% figure;
% plot(testavgf)
% title('afetr equalisation (fuzzy)');


end








    