function[Disteg] = imagedistance(I1,I2,w1,w2,H1,H2,f1,f2)

%This function takes in the features of the two images we wish to compute
%the distance between. The distance between the two images is the output.
% I = input image of orignal size
% w1 = array containing the no of elements in each region of image 1 w1(1,k1)
% w2 = array containing the no of element in each region of image 2  w2(1,k2)
% H1 = fuzzy histogram of image 1 H1(k1,96)
% H2 = fuzzy histogram of image 2 H2(k2,96)
% f1 = vector of texture feature for every region f1(k1,3)



[k1, k3] = size(H1); 
[k2, k4] = size(H2); 
[k5,k6,k9] = size(I1);
N1 = k5 *k6; 
[k7,k8,k10] = size(I2);
N2 = k7*k8;

for x = 1:k1
    for y = 1:k2
        dT(x,y) = sqrt((f1(x,1) - f2(y,1))^2 + (f1(x,2) - f2(y,2))^2 + (f1(x,3) - f2(y,3))^2);   % calculating dT distance between texture features of image 1 and 2 
    end
end

dC = zeros(k1,k2);
for x = 1:k1
    for y = 1:k2
        for i = 1:4
            dC(x,y) = dC(x,y) + (H1(x,i) - H2(y,i))^2;      % calculating distance between fuzzy histogram of different regions of image 1 and image 2 
        end 
        dC(x,y) = sqrt(dC(x,y)/4);
    end 
end 

for x = 1: k1
    for y = 1 : k2
        dCT(x,y) = sqrt((dC(x,y))^2 + (dT(x,y))^2);   % calculating the overall distace between different regions of image 1 and image 2 
    end 
end 
R1 = min(transpose(dCT));
R2 = min(dCT);

W1 = zeros(1,k1);
W2 = zeros(1,k2);

for x = 1: k1 
    W1(1,x) = w1(1,x)/N1;
end 

for y = 1:k2 
    W2(1,y) = w2(1,y)/N2;
end 

Disteg = (W1*transpose(R1) + W2*transpose(R2))/2;
