function testrun(image1,image2)
  
  
        %Extractin Feautures for image 1
        image1=imread(image1);
        disp('Segmenting image 1. Please wait...')
        [outimage1 mask1 K1 histC1 W1]=segment(image1);
        tex1=fuzzyTex(image1,mask1,K1);
        imshow(image1);
        title('Original Image 1');
        figure;
        imshow(outimage1);
        title('Segmented Image 1')
        
        %Extracting features for image 2
        image2=imread(image2);
        disp('Segmenting image 2. Please wait...')
        [outimage2 mask2 K2 histC2 W2]=segment(image2);
        tex2=fuzzyTex(image2,mask2,K2);
        figure;
        imshow(image2);
        title('Original Image 2');
        figure;
        imshow(outimage2);
        title('Segmented Image 2')
        
        
        disp('The distance between the 2 images is:');
        imagedistance(image1,image2,W1,W2,histC1,histC2,tex1,tex2)*10^7
        
end
        