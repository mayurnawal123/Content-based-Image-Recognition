function [out mask K histF w]=segment(image)

  %This function takes in an image and applies the k-means algorithm
  %iteratively for k from 2 to 10. The best value of k is chosen and the
  %outputs are as follows:
   %   1) out= the segmentes image
   %   2) mask=a 2-D array of the size of the input whose each value tells 
   %   3) K=number of the segments
   %   4) histF= the array containing the normalized fuzzy histogram for
   %   each region
   %   5) w=the array containing percentage of number of pixels in each region

    MAX=10;                                 %The number of maximum clusters to be considered.
    
    [x y z]=size(image);
    val=zeros(1,MAX-1);                     %Contains the validity metric of the segmentation for each k. Lower metric => better segmentation.        
    segimages=zeros(x,y,z,MAX);
    
    [mu segimages(:,:,:,2) val(1)]=kmean6D(image,2);        %Segmenting the image for the first time with k=2.
    MU=mu;                                  %This contains the starting means for the next segmentation. (Calculated in the previous iteration.)

    for k=3:MAX
        [mu segimages(:,:,:,k) val(k-1)]=kmean6D(image,k,mu);
        MU=[MU;mu];
    end
    
        
    for i=2:MAX-1
        if(val(i)>val(i-1) && val(i)>val(i+1))
            K=i;
            break;
        end
    end
    
%     disp('First local maxima of validity occurs at');
    disp(K);
%     disp('The number of clusters in the final segmentation')
    K=find(val==min(val(K:end)))+1; 
    disp(K);
    kk= (K*(K-1)/2)-2;
    mu=MU(kk+1:kk+K,:);
    [mu out val mask]=kmean6D(image,K,mu);
    [histF w]=fuzzyhist(image,mask,K);
    w=w/(x*y);

    out=uint8(segimages(:,:,:,K));
    end

        
        