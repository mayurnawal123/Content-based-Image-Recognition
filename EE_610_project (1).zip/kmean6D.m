function [mu,outimage,validity,mask]=kmean6D(ima,k,mu)


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%
%   kmeans image segmentation
%
%   Input:
%          ima: RGB colour image
%          k: Number of classes
%          mu: the means with which the algorithm should start with (basically provided by the previous iteration of the segmentation)
%   Output:
%          mu: vector of class means meant for the next iteration of this
%          algorithm
%          outimage= the segmented image 
%          validity= the metric about the quality of this segmentation
%          mask: clasification image mask
%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


ima=RGB2Lab(ima);           %Converting the image to the Lab colour space.
ima=double(ima);
copy=ima;                   % make a copy

x=size(ima);          %Size of the input image.

img=zeros(x(1)*x(2),3);

%%%%%%% Creating a single one dimensional array to store the image %%%%%%%%
for i=1:x(1)
    for j=1:x(2)
        img((i-1)*x(2)+j,1)=ima(i,j,1);
        img((i-1)*x(2)+j,2)=ima(i,j,2);
        img((i-1)*x(2)+j,3)=ima(i,j,3);
    end
end
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%%%%%%%%%%%%%%%%%%%%% Calculating the Image Histogram %%%%%%%%%%%%%%%%%%%%%
mR=max(img(:,1))+1;               %Max value of the Red(L component) colour
mG=max(img(:,2))+1;               %Colour B (or a component)
mB=max(img(:,3))+1;               %Colour G (or b component)

h=zeros(1,mR*mG*mB);              %This array will actually contain the frequncy of the colour which indexed by its RGB (or Lab) value.
hc=zeros(1,mR*mG*mB);


for i=1:x(1)*x(2)
  img(i,:);
  index = img(i,1)*mB*mG  +   img(i,2)*mB   +   img(i,3) + 1;
  
  h(index)  =  h(index)+1;
end
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

ind=(find(h))'    ;     %All those indices whose frequency is greater than 0
hl=length(ind)   ;      %Number of such indices

%%%%%%%%%%%%%%%%%% Initializing the mean values when k=2 %%%%%%%%%%%%%%%%%%
if (k==2)
    mu(1,:)= 0.3*[mR-1 mG-1 mB-1 ];
    mu(2,:)= 0.6*[mR-1 mG-1 mB-1 ];
end
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


while(true)
  
  oldmu=mu;
  % current classification  
 
  %%% Classifying the intensitites based on the distances form the means %%%
    
  for i=1:hl                                        %This for loop runs h1 times which is the number of the non-zero frequency colours
      
      B=mod( mod (ind(i)-1  ,mB*mG ),mB);           %These values are the colours of the indexed by i in ind(i)
      G=mod((ind(i)-B-1),mB*mG)/mB;
      R=((ind(i)-B-G*mB-1)/mG)/mB;
     
      c=zeros(1,k);                                 %This array will contain the distance of the colour from each of the means
      for l=1:k
          c(l)=sqrt((R-mu(l,1))^2+(G-mu(l,2))^2+(B-mu(l,3))^2);
      end
      
      cc=find(c==min(c));       %cc is the index of the mean which is closest to intensity ind(i)
      hc(ind(i))=cc(1);         %hc contains the index of the mean to which the particular intensity belongs
  end                           % End of the FOR loop
  %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
  
  %%%%%%%%%%%%%%%%%%%%%%%%%% Recalculation of means  %%%%%%%%%%%%%%%%%%%%%%
  
  for i=1:k, 
      a=find(hc==i);            %all those indices of the intensities who belong to the i'th cluster
      B=mod( mod (a-1  ,mB*mG ),mB);
      G=mod(a-B-1,mB*mG)/mB;
      R=((a-B-G*mB-1)/mG)/mB;
      
      if(sum(h(a))~=0)
          mu(i,1)=sum(R.*h(a))/sum(h(a));
          mu(i,2)=sum(G.*h(a))/sum(h(a));
          mu(i,3)=sum(B.*h(a))/sum(h(a));
      end
  end
  %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
  
  if(mu==oldmu)
      %%%%% Time to break and calculate the variance of each of cluster%%%%
      var=zeros(1,k);
      totalvar=0;
      for i=1:k
          a=find(hc==i);
          B=mod( mod (a-1  ,mB*mG ),mB);
          G=mod(a-B-1,mB*mG)/mB;
          R=((a-B-G*mB-1)/mG)/mB;
          if(sum(h(a))~=0)
            var(i)= sum(h(a).*( ((R-mu(i,1)).*(R-mu(i,1)))+((G-mu(i,2)).*(G-mu(i,2)))+((B-mu(i,3)).*(B-mu(i,3))) ))/sum(h(a));
          else
              var(i)=0;
          end
          totalvar=totalvar+var(i)*sum(h(a));   
      end
      totalvar=totalvar/(x(1)*x(2));
      
       %%%%%calculating the intra and validity values %%%%%%%
      intraA=sum((mu(1,:)-mu(2,:)).*(mu(1,:)-mu(2,:)));
      for i=1:k-1
          for j=i+1:k
              intraA = [intraA,sum((mu(i,:)-mu(j,:)).*(mu(i,:)-mu(j,:)))];
          end
      end
      intra=min(intraA);
      validity = totalvar/intra;
      %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
      
      %%%%%% Finding the partitioning of the highest variance cluster %%%%%
      MaxVarClus=find(var==max(var));
      a=find(hc==MaxVarClus);            %all those indices of the intensities who belong to cluster with highest Var
      B=mod( mod (a-1  ,mB*mG ),mB);
      G=mod(a-B-1,mB*mG)/mB;
      R=((a-B-G*mB-1)/mG)/mB;
      
      r1=max(abs(mu(MaxVarClus,1)-R));
      r2=min(abs(mu(MaxVarClus,1)-R));      
      g1=max(abs(mu(MaxVarClus,2)-G));
      g2=min(abs(mu(MaxVarClus,2)-G));      
      b1=max(abs(mu(MaxVarClus,3)-B));
      b2=min(abs(mu(MaxVarClus,3)-B));
      
      r=0.5*min(r1,r2);
      g=0.5*min(g1,g2);
      b=0.5*min(b1,b2); 
     
      newmu1=mu(MaxVarClus,:)-[r g b];
      newmu2=mu(MaxVarClus,:)+[r g b];
      
      mu(MaxVarClus,:)=newmu1;
      mu=[mu; newmu2]; %#ok<AGROW>
      %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
      
     
      break;
  end
  
end             %End of the while loop, i.e. the iteration is complete


%%%%%%%%%%% Calculate the mask of the image and the cluster %%%%%%%%%%%%%
s=size(copy);
mask=zeros(s(1),s(2));
outimage=zeros(s);
for i=1:s(1),
    for j=1:s(2),
      
      c=zeros(1,k);
      for l=1:k             %finding the distance of the colour of each pixel from each of the means
          c(l)=sqrt((copy(i,j,1)-mu(l,1))^2+(copy(i,j,2)-mu(l,2))^2+(copy(i,j,3)-mu(l,3))^2);
      end  
      a=find(c==min(c)); %The cluster# to which this pixel will belong.
      outimage(i,j,1)=mu(a(1),1);
      outimage(i,j,2)=mu(a(1),2);
      outimage(i,j,3)=mu(a(1),3);
      mask(i,j)=a(1);
    end
end
mask=uint8(mask);
outimage=Lab2RGB(outimage);


